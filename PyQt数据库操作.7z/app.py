# coding:utf-8

from PyQt5 import QtCore,QtWidgets,QtSql
from PyQt5.QtWidgets import QApplication,QLineEdit,QWidget,QPushButton,QAction
from PyQt5.QtGui import *


import sys


class MainUi(QtWidgets.QMainWindow):

    def __init__(self):
        super().__init__()
        self.initUi()
        self.initMenu()

    def initMenu(self):
        self.bar = self.menuBar()  # 获取菜单栏
        # 添加顶层菜单
        self.muDatabase = self.bar.addMenu("数据库")
        self.muTable = self.bar.addMenu("数据表")

        # 给顶层菜单添加相应的匹配分菜单
        self.addDataBase = QAction("添加数据库", self)
        self.addDataBase.triggered.connect(self.create_db)  # 菜单栏设置相应的信号触发和槽函数
        self.muDatabase.addAction(self.addDataBase)

        # 给顶层菜单添加相应的匹配分菜单
        self.actTable = QAction("添加数据表", self)
        self.actTable.triggered.connect(self.create_tb)  # 菜单栏设置相应的信号触发和槽函数
        self.actTable.setDisabled(True)

        self.actSubmit = QAction("提交", self)
        self.actSubmit.triggered.connect(self.submit)  # 菜单栏设置相应的信号触发和槽函数
        self.actSubmit.setDisabled(True)

        self.actCRUD = QAction("显示CURD", self)
        self.actCRUD.triggered.connect(self.showCURD)  # 菜单栏设置相应的信号触发和槽函数
        self.actCRUD.setDisabled(True)

        self.muTable.addAction(self.actTable)
        self.muTable.addAction(self.actSubmit)
        self.muTable.addAction(self.actCRUD)




	# 初始化UI界面
    def initUi(self):

        # 设置窗口标题
        self.setWindowTitle("PyQt5-MySQL")
        # 设置窗口大小
        self.resize(600,400)
        # 创建一个窗口部件
        self.widget = QtWidgets.QWidget()
        # 创建一个网格布局
        self.grid_layout = QtWidgets.QGridLayout()
        # 设置窗口部件的布局为网格布局
        self.widget.setLayout(self.grid_layout)
        # 创建一个按钮组
        self.group_box = QtWidgets.QGroupBox('CURD')
        self.group_box_layout = QtWidgets.QVBoxLayout()
        self.group_box.setLayout(self.group_box_layout)
        self.group_box.hide()

        # 创建一个表格部件
        self.table_widget = QtWidgets.QTableView()
        self.table_widget1 = QtWidgets.QTableView()
        # 将上述两个部件添加到网格布局中
        self.grid_layout.addWidget(self.group_box,0,0)
        self.grid_layout.addWidget(self.table_widget,0,1)
        self.grid_layout.addWidget(self.table_widget1, 0, 1)

        self.b_select_edit = QLineEdit("")
        self.b_select_edit.setPlaceholderText("过滤器:")

        # 提交
        # self.b_submit = QtWidgets.QPushButton("提交")
        # self.b_submit.setStyleSheet("color:red")
        # self.b_submit.hide()
        # self.b_submit.clicked.connect(self.submit)

        # 添加数据库
        # self.b_create_db = QtWidgets.QPushButton("添加数据库")
        # self.b_create_db.clicked.connect(self.create_db)

        # 添加数据表
        # self.b_create_tb = QtWidgets.QPushButton("新建数据表")
        # self.b_create_tb.clicked.connect(self.create_tb)

        self.b_view_data = QtWidgets.QPushButton("查询")
        self.b_view_data.clicked.connect(self.view_data)

        self.b_add_row = QtWidgets.QPushButton("添加")
        self.b_add_row.clicked.connect(self.add_row_data)

        self.b_delete_row = QtWidgets.QPushButton("删除")
        self.b_delete_row.clicked.connect(self.del_row_data)

        self.b_close = QtWidgets.QPushButton("隐藏")
        self.b_close.clicked.connect(self.hideCURD)
        # 添加按钮到按钮组中

        self.group_box_layout.addWidget(self.b_select_edit)
        self.group_box_layout.addWidget(self.b_view_data)
        # self.group_box_layout.addWidget(self.b_submit)
        # self.group_box_layout.addWidget(self.b_create_db)
        # self.group_box_layout.addWidget(self.b_create_tb)
        self.group_box_layout.addWidget(self.b_add_row)
        self.group_box_layout.addWidget(self.b_delete_row)
        self.group_box_layout.addWidget(self.b_close)

        # 设置UI界面的核心部件
        self.setCentralWidget(self.widget)

    def showCURD(self):
        self.group_box.show()

    def hideCURD(self):
        self.group_box.hide()

    def submit(self):
        try:
            _str = ""
            for row in range(self.col_num):
                if self.model.index(row, 0).data() != None or self.model.index(row, 1).data() != None:
                    _str += str(self.model.index(row, 0).data()).strip() + " " + str(
                        self.model.index(row, 1).data()).strip() + ","

            _str = _str[:-1]
            # 创建一个数据库表
            self.sql = "create table {0} ({1})".format(self.tb_name, str(_str))
            query = QtSql.QSqlQuery()
            ret = query.exec_(self.sql)
            if ret:
                print("数据表创建成功!")
                self.actCRUD.setDisabled(False)
                self.view_data()


            else:
                print("数据表创建失败!")

        except Exception as e:
            print(e)
    # 创建数据库
    def create_db(self):
        try:
            # 调用输入框获取数据库名称
            db_text, db_action = QtWidgets.QInputDialog.getText(self, '数据库名称', '请输入数据库名称', QtWidgets.QLineEdit.Normal)

            if (db_text.replace(' ', '') != '') and (db_action is True):
                print(db_text)
                print(QtSql.QSqlDatabase.drivers())
                self.db_name = db_text
                # 添加一个sqlite数据库连接并打开
                db = QtSql.QSqlDatabase.addDatabase("QMYSQL")
                db.setHostName("127.0.0.1")
                db.setDatabaseName(self.db_name)  # 自己的数据库名字
                db.setUserName("root")
                db.setPassword("root")
                db.setPort(3306)
                r = db.open()
                print(r)
                if r:
                    print("连接成功!")
                    self.actTable.setDisabled(False)
                    self.actSubmit.setDisabled(False)


                else:
                    print("连接失败!")

        except Exception as e:
            print(e)

    # 创建数据表
    def create_tb(self):
            try:

                    # 请输入字段,如ID int primary key,site_name varchar(20)
                    tb_text, tb_action = QtWidgets.QInputDialog.getText(self, '数据表名称', '请输入数据表名称',
                                                                        QtWidgets.QLineEdit.Normal)
                    col_text, col_action = QtWidgets.QInputDialog.getText(self, '字段数', '', QtWidgets.QLineEdit.Normal)
                    if (tb_text.replace(' ', '') != '') and (tb_action is True) and (col_text != '请输入字段数量') and (
                            col_action is True):
                        self.tb_name = tb_text
                        self.col_num = int(col_text)

                        self.table_widget.hide()
                        self.table_widget1.show()

                        self.model = QStandardItemModel(self.col_num, 2)
                        self.model.setHeaderData(0, QtCore.Qt.Horizontal, '字段')
                        self.model.setHeaderData(1, QtCore.Qt.Horizontal, '类型')
                        self.table_widget1.setModel(self.model)


            except Exception as e:
                print(e)




    def view_data(self):
        # 实例化一个可编辑数据模型
        self.table_widget1.hide()
        self.table_widget.show()


        self.model = QtSql.QSqlTableModel()
        self.table_widget.setModel(self.model)
        self.model.setTable(self.tb_name) # 设置数据模型的数据表
        self.model.setEditStrategy(QtSql.QSqlTableModel.OnFieldChange) # 允许字段更改

        query = self.b_select_edit.text()
        if query != "":
            self.model.setFilter(query)
        self.model.select() # 查询所有数据


    # 添加一行数据行
    def add_row_data(self):
        # 如果存在实例化的数据模型对象
        if self.model:
            self.model.insertRows(self.model.rowCount(), 1)
        else:
            self.create_db()
        self.model.submit()


    # 删除一行数据
    def del_row_data(self):
        if self.model:
            self.model.removeRow(self.table_widget.currentIndex().row())
        else:
            self.create_db()
        self.model.submit()


if __name__ == '__main__':
    app = QApplication(sys.argv)
    winMain = MainUi()
    winMain.show()
    sys.exit(app.exec_())
