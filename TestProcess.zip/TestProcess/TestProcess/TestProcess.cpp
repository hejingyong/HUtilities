﻿// TestProcess.cpp : 此文件包含 "main" 函数。程序执行将在此处开始并结束。
//

#include <iostream>
#include <windows.h>
#include <stdio.h>

using namespace std;

void StartClone(int nCloneId) {

	TCHAR szFilename[MAX_PATH];
	::GetModuleFileName(NULL, szFilename, MAX_PATH);
	TCHAR szCmdLine[MAX_PATH];
	::sprintf(szCmdLine, "\\%s %d", szFilename, nCloneId);
	STARTUPINFO si;
	::ZeroMemory(reinterpret_cast<void *>(&si),sizeof(si));
	si.cb = sizeof(si);
	PROCESS_INFORMATION pi;
	BOOL bCreateOK = ::CreateProcess(
		szFilename,
		szCmdLine,
		NULL,
		NULL,
		FALSE,
		CREATE_NEW_CONSOLE,
		NULL,
		NULL,
		&si,
		&pi
	);
	if (bCreateOK)
	{
		::CloseHandle(pi.hProcess);
		::CloseHandle(pi.hThread);

	}

		
}
int main(int argc,char* argv[])
{
	int nClone = 0;
	if (argc > 1)
	{

		::sscanf(argv[1], "%d", &nClone);
	}
	cout << "Process ID:" << ::GetCurrentProcessId() << ",Clone ID:" << nClone << endl;
	const int c_nCLoneMax = 25;
	if (nClone < c_nCLoneMax)
	{
		StartClone(++nClone);
	}
	::Sleep(500);
	system("pause");

}

// 运行程序: Ctrl + F5 或调试 >“开始执行(不调试)”菜单
// 调试程序: F5 或调试 >“开始调试”菜单

// 入门使用技巧: 
//   1. 使用解决方案资源管理器窗口添加/管理文件
//   2. 使用团队资源管理器窗口连接到源代码管理
//   3. 使用输出窗口查看生成输出和其他消息
//   4. 使用错误列表窗口查看错误
//   5. 转到“项目”>“添加新项”以创建新的代码文件，或转到“项目”>“添加现有项”以将现有代码文件添加到项目
//   6. 将来，若要再次打开此项目，请转到“文件”>“打开”>“项目”并选择 .sln 文件
