# -*- coding: utf-8 -*- 
import socket
import threading
 
# 监听的IP及端口
bind_ip = "127.0.0.1"
bind_port = 9999
 
server = socket.socket(socket.AF_INET,socket.SOCK_STREAM) # Create Socket Server
server.bind((bind_ip,bind_port)) # bind ip and port
server.listen(5) # max connection
print ("[+] Listening on %s:%d" % (bind_ip,bind_port))
 
def handle_client(client_socket):
    #request = client_socket.recv(1024) 
    #print "[*] Received:%s" % request
    #client_socket.send("ok!") 
    #client_socket.close()
    command = str(input("$:->")).encode() # encode to bin
    command_len = str(len(command)).encode()
    client_socket.send(command_len)
    client_socket.send(command)
    client_message_len = int(client_socket.recv(1024).decode())
    client_message = ''
    for i in range(client_message_len // 1024 +1 ):
        client_message += client_socket.recv(1024).decode()
    print("[*] Received:%s" % client_message)

 
while True: 
    client,info = server.accept() # control the other side's socket service and connection information
    print("[*] Accept connection from:%s:%d" % (info[0],info[1]))
    client_handler = threading.Thread(target=handle_client,args=(client,)) 
    client_handler.start()

